from flask import Flask, render_template, request, redirect, url_for
from pymongo import MongoClient
from bson import ObjectId

app = Flask(__name__)

client = MongoClient('mongodb://localhost:27017/')
db = client['user']
collection = db['employee']

@app.route('/')
def index():
    search_query = request.args.get('search', '')
    query = {}  # Empty query for fetching all records

    if search_query:
        # If search query exists, filter by name containing the search term
        query = {'name': {'$regex': f'.*{search_query}.*', '$options': 'i'}},
        query = {'organization': {'$regex': f'.*{search_query}.*', '$options': 'i'}}

    employees = list(collection.find(query))
    return render_template('index.html', employees=employees, search_query=search_query)

@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        employee = {
            'name': request.form.get('name'),
            'organization': request.form.get('organization'),
            'salary': request.form.get('salary')
        }
        collection.insert_one(employee)
        return redirect(url_for('index'))

    return render_template('add.html')

@app.route('/edit/<string:id>', methods=['GET', 'POST'])
def edit(id):
    if request.method == 'GET':
        employee = collection.find_one({'_id': ObjectId(id)})
        return render_template('edit.html', employee=employee)
    else:
        updated_data = {
            'name': request.form.get('name'),
            'organization': request.form.get('organization'),
            'salary': request.form.get('salary')
        }
        collection.update_one({'_id': ObjectId(id)}, {'$set': updated_data})
        return redirect(url_for('index'))

@app.route('/delete/<string:id>')
def delete(id):
    collection.delete_one({'_id': ObjectId(id)})
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
